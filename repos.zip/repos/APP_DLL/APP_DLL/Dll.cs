﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APP_DLL
{
    public class Dll
    {
        public void create(string racf, int funcional)
        {
            ServiceReference1.ServiceClient x = new ServiceReference1.ServiceClient();

            try
            {
                x.Criar(racf, funcional);

            }
            catch (Exception ex)
            {
                throw new Exception("Error", ex);
            }

        }
    }
}
